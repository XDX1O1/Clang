#include <stdio.h>

#define CAPACITY 10
typedef struct {
  int time;
} Customer;

typedef struct {
  Customer customers[CAPACITY];
  int front;
  int rear;
} Queue;

void createQueue(Queue *q) {
  q->front = 0;
  q->rear = 0;
}

int isEmpty(Queue *q) { return q->front == q->rear; }

void enqueue(Queue *q, Customer customer) {
  if ((q->rear + 1) % CAPACITY == q->front) {
    printf("Queue is full. Cannot add customer.\n");
    return;
  }

  q->customers[q->rear] = customer;
  q->rear = (q->rear + 1) % CAPACITY;
}

Customer dequeue(Queue *q) {
  if (isEmpty(q)) {
    printf("Queue is empty. Cannot remove customer.\n");
    Customer emptyCustomer = {0};
    return emptyCustomer;
  }

  Customer customer = q->customers[q->front];
  q->front = (q->front + 1) % CAPACITY;
  return customer;
}

int main() {
  Queue q;
  createQueue(&q);

  enqueue(&q, (Customer){15});
  enqueue(&q, (Customer){30});
  enqueue(&q, (Customer){45});

  printf("First customer to leave: %d minutes\n", dequeue(&q).time);
  printf("Second customer to leave: %d minutes\n", dequeue(&q).time);
  printf("Third customer to leave: %d minutes\n", dequeue(&q).time);

  return 0;
}
