#include <stdio.h>

#define MAX 10

int queue_array[MAX];
int front = -1;
int rear = -1;

int isEmpty();
int isFull();
void enqueue(int value);
void dequeue();

int main() {
  int value;
  char ch;

  for (int i = 0; i < 10; i++) {
    printf("Masukan Prioritas Pasien 1-3 : ");
    scanf("%d", &value);
    enqueue(value);
  }

  for (int i = 0; i < 10; i++) {
    dequeue();
  }

  return 0;
}

int isEmpty() {
  if (front == -1)
    return 1;
  else
    return 0;
}

int isFull() {
  if (rear == MAX - 1)
    return 1;
  else
    return 0;
}

void enqueue(int value) {
  if (isFull())
    printf("queue penuh\n");
  else {
    if (front == -1)
      front = 0;
    rear++;
    queue_array[rear] = value;
  }
}

void dequeue() {
  if (isEmpty())
    printf("queue kosong\n");
  else {
    int value = queue_array[front];
    front++;
    if (front > rear) {
      front = rear = -1;
    }

    if (value == 3) {
      printf("pasien prioritas sangat darurat\n");
    } else if (value == 2) {
      printf("pasien prioritas darurat\n");
    } else {
      printf("pasien normal\n");
    }
  }
}
