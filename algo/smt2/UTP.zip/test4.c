#include <stdio.h>
#include <stdio.h>

int main() {

  char c;
  printf("Masukan Karakter Angka Diantara 0 - 9 : ");
  scanf(" %c", &c);

  if (c >= '0' && c <= '9') {
    printf("Dikonversikan Ke Integer %d\n", c - '0');
  } else {
    printf("Input Salah, Masukan Angka Diantara 0 - 9.\n");
  }

  return 0;
}
