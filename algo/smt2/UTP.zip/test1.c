#include <stdio.h>
#include <string.h>

#define MAX 100

typedef struct {
  char string[MAX];
  int size;
} stack;

void push(stack *s, char c) {
  if (s->size < MAX) {
    s->string[s->size] = c;
    s->size++;
  }
}

char pop(stack *s) {
  if (s->size > 0) {
    s->size--;
    return s->string[s->size];
  }
  return '\0';
}

void reverse_string(stack *s, char *str) {
  int i;
  for (i = 0; str[i] != '\0'; i++) {
    push(s, str[i]);
  }
  for (i = 0; i < strlen(str); i++) {
    str[i] = pop(s);
  }
}

int main() {
  stack string;
  string.size = 0;
  char str[] = "Halo";
  reverse_string(&string, str);
  printf("%s\n", str);
  return 0;
}
